package enums;

public enum EIdioma {
	Spanish,
	English
}
