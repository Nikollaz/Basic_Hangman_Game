package enums;

public enum EEstadoJugador {
	Jugando,
	Perdio,
	Gano
}
